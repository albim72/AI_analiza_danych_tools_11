"""
StatDash – wysyłka e-mail przez SMTP (biblioteka standardowa Pythona).
Konfiguracja trzymana lokalnie w smtp_config.json (obok aplikacji).
"""
from __future__ import annotations

import json
import os
import re
import smtplib
import socket
import ssl
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "smtp_config.json")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

DEFAULTS = {
    "host": "smtp.gmail.com",
    "port": 587,
    "security": "starttls",  # starttls | ssl | none
    "username": "",
    "password": "",
    "from_email": "",
    "from_name": "StatDash",
    "remember_password": True,
}

PRESETS = {
    "gmail": {"host": "smtp.gmail.com", "port": 587, "security": "starttls"},
    "outlook": {"host": "smtp.office365.com", "port": 587, "security": "starttls"},
    "onet": {"host": "smtp.poczta.onet.pl", "port": 465, "security": "ssl"},
    "wp": {"host": "smtp.wp.pl", "port": 465, "security": "ssl"},
    "o2": {"host": "poczta.o2.pl", "port": 465, "security": "ssl"},
    "interia": {"host": "poczta.interia.pl", "port": 465, "security": "ssl"},
}

_session_password: str = ""  # hasło tylko w pamięci, gdy użytkownik nie chce go zapisywać


def load_config(include_password: bool = False) -> dict:
    cfg = dict(DEFAULTS)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as fh:
                cfg.update(json.load(fh))
        except (OSError, json.JSONDecodeError):
            pass
    if not cfg.get("password") and _session_password:
        cfg["password"] = _session_password
    # zmienna środowiskowa ma pierwszeństwo (bezpieczniejsza opcja)
    if os.environ.get("STATDASH_SMTP_PASSWORD"):
        cfg["password"] = os.environ["STATDASH_SMTP_PASSWORD"]
    if not include_password:
        cfg["has_password"] = bool(cfg.get("password"))
        cfg["password"] = ""
    return cfg


def save_config(new: dict) -> dict:
    global _session_password
    cur = load_config(include_password=True)
    for k in DEFAULTS:
        if k in new and k != "password":
            cur[k] = new[k]
    try:
        cur["port"] = int(cur["port"])
    except (TypeError, ValueError):
        raise ValueError("Port musi być liczbą (np. 587 lub 465).")
    if new.get("password"):  # puste pole = nie zmieniaj hasła
        cur["password"] = new["password"]
    _session_password = cur.get("password", "")
    to_disk = dict(cur)
    if not cur.get("remember_password"):
        to_disk["password"] = ""
    to_disk.pop("has_password", None)
    with open(CONFIG_PATH, "w", encoding="utf-8") as fh:
        json.dump(to_disk, fh, ensure_ascii=False, indent=2)
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass
    return load_config()


def _connect(cfg: dict) -> smtplib.SMTP:
    host, port, sec = cfg["host"], int(cfg["port"]), cfg.get("security", "starttls")
    ctx = ssl.create_default_context()
    if sec == "ssl":
        server: smtplib.SMTP = smtplib.SMTP_SSL(host, port, timeout=20, context=ctx)
    else:
        server = smtplib.SMTP(host, port, timeout=20)
        server.ehlo()
        if sec == "starttls":
            server.starttls(context=ctx)
            server.ehlo()
    if cfg.get("username"):
        server.login(cfg["username"], cfg.get("password", ""))
    return server


def _friendly_error(exc: Exception) -> str:
    if isinstance(exc, smtplib.SMTPAuthenticationError):
        return ("Serwer odrzucił login lub hasło. Dla Gmaila/Outlooka użyj hasła aplikacji "
                "(Gmail: Konto Google → Bezpieczeństwo → Hasła do aplikacji; wymaga weryfikacji dwuetapowej).")
    if isinstance(exc, smtplib.SMTPRecipientsRefused):
        return "Serwer odrzucił adres odbiorcy – sprawdź, czy jest poprawny."
    if isinstance(exc, smtplib.SMTPSenderRefused):
        return "Serwer odrzucił adres nadawcy – zwykle musi być taki sam jak login."
    if isinstance(exc, (socket.gaierror,)):
        return "Nie można znaleźć serwera SMTP – sprawdź nazwę hosta i połączenie z internetem."
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return "Przekroczono czas połączenia – sprawdź port i rodzaj szyfrowania (587 = STARTTLS, 465 = SSL)."
    if isinstance(exc, ssl.SSLError):
        return "Błąd szyfrowania – spróbuj zmienić tryb (587 → STARTTLS, 465 → SSL)."
    if isinstance(exc, ConnectionRefusedError):
        return "Połączenie odrzucone – zły port albo serwer nie przyjmuje połączeń."
    return f"{type(exc).__name__}: {exc}"


def test_connection() -> tuple[bool, str]:
    cfg = load_config(include_password=True)
    if not cfg.get("host"):
        return False, "Uzupełnij adres serwera SMTP."
    try:
        s = _connect(cfg)
        s.noop()
        s.quit()
        return True, f"Połączono z {cfg['host']}:{cfg['port']}" + (" i zalogowano poprawnie." if cfg.get("username") else " (bez logowania).")
    except Exception as exc:  # noqa: BLE001
        return False, _friendly_error(exc)


def send_mail(to: list[str], subject: str, text_body: str, html_body: str | None,
              attachments: list[tuple[str, bytes, str, str]]) -> tuple[bool, str]:
    """attachments: lista (nazwa_pliku, bajty, maintype, subtype)."""
    cfg = load_config(include_password=True)
    bad = [t for t in to if not EMAIL_RE.match(t)]
    if not to or bad:
        return False, "Niepoprawny adres e-mail: " + ", ".join(bad or ["(pusty)"])
    sender = cfg.get("from_email") or cfg.get("username")
    if not sender or not EMAIL_RE.match(sender):
        return False, "Ustaw adres nadawcy w ustawieniach SMTP."

    msg = EmailMessage()
    msg["From"] = formataddr((cfg.get("from_name") or "", sender))
    msg["To"] = ", ".join(to)
    msg["Subject"] = subject or "Dashboard statystyczny"
    msg["Message-ID"] = make_msgid(domain=sender.split("@")[-1])
    msg.set_content(text_body or "W załączniku dashboard statystyczny.")
    if html_body:
        msg.add_alternative(html_body, subtype="html")
    for fname, data, maintype, subtype in attachments:
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=fname)

    try:
        s = _connect(cfg)
        s.send_message(msg)
        s.quit()
    except Exception as exc:  # noqa: BLE001
        return False, _friendly_error(exc)
    size_kb = sum(len(a[1]) for a in attachments) / 1024
    size_txt = f"{size_kb:,.0f}".replace(",", "\u00a0")
    return True, f"Wysłano do: {', '.join(to)} (załączniki: {len(attachments)}, {size_txt} KB)."
