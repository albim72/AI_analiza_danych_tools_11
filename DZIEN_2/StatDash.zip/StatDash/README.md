# StatDash – lokalny dashboard statystyczny (CSV / Excel)

Mini-aplikacja działająca w przeglądarce na Twoim komputerze (`http://127.0.0.1:5050`).
Dane nie są nigdzie wysyłane, chyba że sam wyślesz dashboard mailem.

## Uruchomienie

Potrzebny jest **Python 3.10 lub nowszy** ([python.org](https://www.python.org/downloads/); w Windowsie podczas instalacji zaznacz *Add Python to PATH*).

| System | Co kliknąć |
|---|---|
| Windows | `start_windows.bat` (dwuklik) |
| macOS | `start_mac.command` (dwuklik; za pierwszym razem: prawy klik → Otwórz) |
| Linux | `./start_mac_linux.sh` |

Przy pierwszym starcie skrypt tworzy środowisko `.venv` i instaluje biblioteki (ok. 1 minuty, potrzebny internet).
Później startuje od razu. Przeglądarka otwiera się sama.

Ręcznie: `pip install -r requirements.txt`, potem `python app.py` (opcje: `--port 8080`, `--no-browser`).

## Co robi

1. **Wczytanie danych**: CSV/TSV/TXT (separator `,` `;` lub tab wykrywany automatycznie, przecinek dziesiętny, kodowanie UTF-8/Windows-1250), Excel `.xlsx` z wyborem arkusza, wklejenie z Excela lub dane przykładowe.
2. **Statystyki opisowe** dla każdej kolumny liczbowej:
   - położenie: średnia, mediana, dominanta, średnia ucinana 10%, średnia geometryczna i harmoniczna;
   - rozproszenie: odchylenie standardowe, wariancja, odchylenie przeciętne, MAD, współczynnik zmienności, rozstęp, IQR;
   - percentyle: P1, P5, P10, Q1, Q3, P90, P95, P99, min, max;
   - kształt: skośność, kurtoza, test normalności Jarque-Bera z wartością p;
   - wnioskowanie: błąd standardowy średniej i 95% przedział ufności (t-Studenta);
   - jakość danych: braki, obserwacje odstające (1,5·IQR oraz |z|>3);
   - korelacje Pearsona i Spearmana; dla kolumn tekstowych: liczba unikalnych wartości i najczęstsze kategorie.
3. **Wykresy**: histogram z krzywą normalną oraz średnią i medianą, wykres pudełkowy (opcjonalnie standaryzowany), wykres rozrzutu z regresją liniową (r, R², równanie) i macierz korelacji.
4. **Automatyczne wnioski**: skośność, duża zmienność, obserwacje odstające, silne korelacje.
5. **Eksport**: HTML (jeden samodzielny plik), PDF (A4 poziomo), Excel (statystyki, korelacje, kategorie, dane).
6. **Wysyłka mailem**: wybierasz załączniki (HTML/PDF/Excel), a treść maila zawiera wskaźniki KPI i najważniejsze wnioski.

## Konfiguracja poczty

Przycisk **✉ Ustawienia poczty** → wybierz dostawcę (Gmail, Outlook, Onet, WP, o2, Interia lub własny serwer) → login → hasło → **Zapisz i testuj połączenie**.

- **Gmail**: wymaga *hasła aplikacji* (Konto Google → Bezpieczeństwo → Weryfikacja dwuetapowa → Hasła do aplikacji). Zwykłe hasło zostanie odrzucone.
- **Outlook / Microsoft 365**: jeśli administrator wyłączył SMTP AUTH, wysyłka nie zadziała. Wtedy pobierz PDF/HTML i dołącz go ręcznie.
- Ustawienia zapisują się lokalnie w `smtp_config.json`. Jeśli odznaczysz „Zapamiętaj hasło”, hasło jest trzymane tylko do zamknięcia aplikacji.
  Możesz też podać hasło w zmiennej środowiskowej `STATDASH_SMTP_PASSWORD`.

## Struktura

```
app.py            serwer Flask + API
stats_engine.py   wczytywanie danych i statystyki
report.py         raport HTML / PDF / XLSX
mailer.py         SMTP
templates/, static/   interfejs (Chart.js dołączony lokalnie, działa offline)
fonts/            DejaVu Sans (polskie znaki w PDF)
sample_data/      przykładowe dane CSV i XLSX
```

Uwagi metodologiczne: odchylenie standardowe i wariancja są liczone z próby (n−1). Percentyle liczone są z interpolacją liniową, tak jak `PERCENTYL.PRZEDZ.ZAMK` w Excelu. Skośność i kurtoza mają korektę próby, tak jak `SKOŚNOŚĆ` i `KURTOZA` w Excelu. Przy ponad 20 000 wierszy statystyki są liczone na wszystkich danych, a wykresy na losowej próbie 20 000.
