"""
StatDash – silnik wczytywania danych i statystyk opisowych.
Wymaga: pandas, numpy, openpyxl. (scipy NIE jest wymagane.)
"""
from __future__ import annotations

import csv
import io
import math
import re
from typing import Any

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Wczytywanie
# ---------------------------------------------------------------------------

_NUM_RE_COMMA = re.compile(r"^[+-]?\d{1,3}([  .]?\d{3})*(,\d+)?$|^[+-]?\d+(,\d+)?$")


def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "cp1250", "iso-8859-2", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _sniff_delimiter(text: str) -> str:
    sample = "\n".join(text.splitlines()[:50])
    try:
        return csv.Sniffer().sniff(sample, delimiters=";,\t|").delimiter
    except csv.Error:
        counts = {d: sample.count(d) for d in (";", ",", "\t", "|")}
        return max(counts, key=counts.get) if max(counts.values()) > 0 else ","


def _to_number_series(s: pd.Series) -> pd.Series | None:
    """Próbuje zamienić kolumnę tekstową na liczby (obsługa przecinka dziesiętnego,
    spacji tysięcy, znaku %). Zwraca None, jeśli kolumna nie jest liczbowa."""
    if pd.api.types.is_numeric_dtype(s):
        return s.astype(float)
    if pd.api.types.is_bool_dtype(s):
        return None
    txt = s.dropna().astype(str).str.strip()
    txt = txt[txt != ""]
    if txt.empty:
        return None
    cleaned = (
        s.astype(str).str.strip()
        .str.replace(" ", "", regex=False)
        .str.replace("%", "", regex=False)
    )
    cleaned = cleaned.where(~cleaned.isin(["", "nan", "NaN", "None", "NA", "N/A", "-", "brak"]))
    nonempty = cleaned.dropna()
    # przecinek dziesiętny: "1 234,56" / "12,5"
    comma_style = nonempty.str.match(_NUM_RE_COMMA).mean() > 0.6 and nonempty.str.contains(",").any()
    if comma_style:
        cleaned = cleaned.str.replace(r"[ .](?=\d{3}(\D|$))", "", regex=True).str.replace(",", ".", regex=False)
    else:
        cleaned = cleaned.str.replace(r"(?<=\d)[ ,](?=\d{3}(\D|$))", "", regex=True)
    num = pd.to_numeric(cleaned, errors="coerce")
    ratio = num.notna().sum() / max(len(nonempty), 1)
    return num.astype(float) if ratio >= 0.8 else None


def _normalize_frame(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # nazwy kolumn
    cols, seen = [], {}
    for i, c in enumerate(df.columns):
        name = str(c).strip() if str(c).strip() and not str(c).startswith("Unnamed") else f"Kolumna_{i + 1}"
        if name in seen:
            seen[name] += 1
            name = f"{name}_{seen[name]}"
        else:
            seen[name] = 0
        cols.append(name)
    df.columns = cols
    df = df.dropna(how="all").dropna(axis=1, how="all")
    for c in df.columns:
        conv = _to_number_series(df[c])
        if conv is not None:
            df[c] = conv
    return df.reset_index(drop=True)


def load_table(raw: bytes, filename: str, sheet: str | None = None) -> tuple[pd.DataFrame, list[str]]:
    """Zwraca (DataFrame, lista_arkuszy). Obsługuje .csv/.tsv/.txt oraz .xlsx/.xlsm."""
    name = (filename or "").lower()
    sheets: list[str] = []
    if name.endswith((".xlsx", ".xlsm", ".xltx")):
        xls = pd.ExcelFile(io.BytesIO(raw), engine="openpyxl")
        sheets = list(xls.sheet_names)
        use = sheet if sheet in sheets else sheets[0]
        df = xls.parse(use)
    elif name.endswith(".xls"):
        raise ValueError("Stary format .xls nie jest obsługiwany – zapisz plik jako .xlsx lub CSV.")
    else:
        text = _decode(raw)
        if not text.strip():
            raise ValueError("Plik jest pusty.")
        delim = "\t" if name.endswith(".tsv") else _sniff_delimiter(text)
        df = pd.read_csv(io.StringIO(text), sep=delim, dtype=str, skipinitialspace=True,
                         engine="python", on_bad_lines="skip")
    df = _normalize_frame(df)
    if df.empty:
        raise ValueError("Nie znaleziono danych w pliku.")
    return df, sheets


# ---------------------------------------------------------------------------
# Statystyki
# ---------------------------------------------------------------------------

def _t_crit_975(df: int) -> float:
    """Kwantyl 0,975 rozkładu t-Studenta (rozwinięcie Cornisha-Fishera; błąd < 0,001 dla df≥3)."""
    table = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571}
    if df in table:
        return table[df]
    z = 1.959964
    g1 = (z ** 3 + z) / 4
    g2 = (5 * z ** 5 + 16 * z ** 3 + 3 * z) / 96
    g3 = (3 * z ** 7 + 19 * z ** 5 + 17 * z ** 3 - 15 * z) / 384
    return z + g1 / df + g2 / df ** 2 + g3 / df ** 3


def _f(x: Any) -> float | None:
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    return None if (math.isnan(x) or math.isinf(x)) else x


def describe_numeric(s: pd.Series) -> dict[str, Any]:
    total = len(s)
    x = s.dropna().to_numpy(dtype=float)
    n = len(x)
    out: dict[str, Any] = {"n": n, "braki": total - n}
    if n == 0:
        return out
    mean = x.mean()
    med = float(np.median(x))
    std = x.std(ddof=1) if n > 1 else 0.0
    q = np.percentile(x, [1, 5, 10, 25, 75, 90, 95, 99])
    q1, q3 = q[3], q[4]
    iqr = q3 - q1
    lo_f, hi_f = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outl = x[(x < lo_f) | (x > hi_f)]
    m2 = ((x - mean) ** 2).mean()
    m3 = ((x - mean) ** 3).mean()
    m4 = ((x - mean) ** 4).mean()
    # skośność i kurtoza z korektą próby (jak w Excelu: SKOŚNOŚĆ / KURTOZA)
    skew = kurt = None
    if n > 2 and m2 > 0:
        g1 = m3 / m2 ** 1.5
        skew = g1 * math.sqrt(n * (n - 1)) / (n - 2)
    if n > 3 and m2 > 0:
        g2 = m4 / m2 ** 2 - 3
        kurt = ((n + 1) * g2 + 6) * (n - 1) / ((n - 2) * (n - 3))
    sem = std / math.sqrt(n) if n > 1 else None
    tcrit = _t_crit_975(n - 1) if n > 1 else None
    vals, counts = np.unique(x, return_counts=True)
    mode = float(vals[counts.argmax()]) if counts.max() > 1 else None
    trim_k = int(n * 0.1)
    xs = np.sort(x)
    trimmed = xs[trim_k:n - trim_k].mean() if n - 2 * trim_k > 0 else mean
    z = (x - mean) / std if std > 0 else np.zeros_like(x)
    jb = jb_p = None
    if n > 7 and skew is not None and kurt is not None and m2 > 0:
        g1 = m3 / m2 ** 1.5
        g2 = m4 / m2 ** 2 - 3
        jb = n / 6 * (g1 ** 2 + g2 ** 2 / 4)
        jb_p = math.exp(-jb / 2)  # chi^2(2): P(X>jb) = e^(-jb/2)

    out.update({
        "suma": x.sum(),
        "srednia": mean,
        "mediana": med,
        "dominanta": mode,
        "srednia_ucinana_10": trimmed,
        "srednia_geometryczna": float(np.exp(np.log(x).mean())) if (x > 0).all() else None,
        "srednia_harmoniczna": float(n / (1.0 / x).sum()) if (x > 0).all() else None,
        "odch_std": std,
        "wariancja": std ** 2,
        "odch_przecietne": float(np.abs(x - mean).mean()),
        "mad_mediana": float(np.median(np.abs(x - med))),
        "wsp_zmiennosci_proc": (std / abs(mean) * 100) if mean != 0 else None,
        "blad_std_sredniej": sem,
        "ci95_dol": mean - tcrit * sem if sem is not None else None,
        "ci95_gora": mean + tcrit * sem if sem is not None else None,
        "min": xs[0], "max": xs[-1], "rozstep": xs[-1] - xs[0],
        "p1": q[0], "p5": q[1], "p10": q[2], "q1": q1, "q3": q3, "p90": q[5], "p95": q[6], "p99": q[7],
        "iqr": iqr,
        "skosnosc": skew,
        "kurtoza": kurt,
        "jarque_bera": jb,
        "jb_p": jb_p,
        "outliery_iqr": int(len(outl)),
        "outliery_z3": int((np.abs(z) > 3).sum()),
    })
    return {k: (_f(v) if isinstance(v, (float, np.floating, np.integer)) and k not in ("n", "braki", "outliery_iqr", "outliery_z3") else v)
            for k, v in out.items()}


# kolejność + polskie etykiety + krótki opis (używane w UI i raportach)
MEASURES: list[tuple[str, str, str]] = [
    ("n", "Liczba obserwacji (N)", "Wartości niepuste"),
    ("braki", "Braki danych", "Puste komórki"),
    ("srednia", "Średnia", "Średnia arytmetyczna"),
    ("mediana", "Mediana", "Wartość środkowa (P50)"),
    ("dominanta", "Dominanta", "Najczęstsza wartość (gdy się powtarza)"),
    ("srednia_ucinana_10", "Średnia ucinana 10%", "Średnia bez 10% skrajnych wartości z każdej strony"),
    ("srednia_geometryczna", "Średnia geometryczna", "Tylko dla wartości > 0"),
    ("srednia_harmoniczna", "Średnia harmoniczna", "Tylko dla wartości > 0"),
    ("odch_std", "Odchylenie standardowe", "Z próby (n−1)"),
    ("wariancja", "Wariancja", "Z próby (n−1)"),
    ("odch_przecietne", "Odchylenie przeciętne", "Średnie bezwzględne odchylenie od średniej"),
    ("mad_mediana", "MAD (od mediany)", "Mediana bezwzględnych odchyleń od mediany"),
    ("wsp_zmiennosci_proc", "Współczynnik zmienności [%]", "Odch. std / |średnia| × 100"),
    ("blad_std_sredniej", "Błąd standardowy średniej", "SEM = s / √n"),
    ("ci95_dol", "95% CI średniej – dół", "Przedział ufności t-Studenta"),
    ("ci95_gora", "95% CI średniej – góra", "Przedział ufności t-Studenta"),
    ("min", "Minimum", ""),
    ("p1", "Percentyl 1", ""),
    ("p5", "Percentyl 5", ""),
    ("p10", "Percentyl 10", ""),
    ("q1", "Kwartyl Q1 (P25)", ""),
    ("q3", "Kwartyl Q3 (P75)", ""),
    ("p90", "Percentyl 90", ""),
    ("p95", "Percentyl 95", ""),
    ("p99", "Percentyl 99", ""),
    ("max", "Maksimum", ""),
    ("rozstep", "Rozstęp", "Max − Min"),
    ("iqr", "Rozstęp ćwiartkowy (IQR)", "Q3 − Q1"),
    ("skosnosc", "Skośność", "> 0: prawostronna, < 0: lewostronna"),
    ("kurtoza", "Kurtoza (nadwyżkowa)", "> 0: grubsze ogony niż rozkład normalny"),
    ("jarque_bera", "Test Jarque-Bera (JB)", "Test normalności rozkładu"),
    ("jb_p", "JB – wartość p", "p < 0,05 → rozkład istotnie różny od normalnego"),
    ("outliery_iqr", "Obserwacje odstające (1,5·IQR)", "Poza [Q1−1,5·IQR; Q3+1,5·IQR]"),
    ("outliery_z3", "Obserwacje odstające (|z|>3)", ""),
    ("suma", "Suma", ""),
]


def describe_categorical(s: pd.Series, top: int = 6) -> dict[str, Any]:
    x = s.dropna().astype(str).str.strip()
    x = x[x != ""]
    vc = x.value_counts()
    return {
        "n": int(len(x)),
        "braki": int(len(s) - len(x)),
        "unikalne": int(vc.size),
        "top": [{"wartosc": k, "liczba": int(v), "proc": float(v / len(x) * 100) if len(x) else 0.0}
                for k, v in vc.head(top).items()],
    }


def _corr(df: pd.DataFrame, method: str) -> list[list[float | None]]:
    if df.shape[1] < 2:
        return []
    m = df.corr(method=method, min_periods=3)
    return [[_f(v) for v in row] for row in m.to_numpy()]


def analyze(df: pd.DataFrame, max_points: int = 20000) -> dict[str, Any]:
    num_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    cat_cols = [c for c in df.columns if c not in num_cols]
    num_df = df[num_cols]
    numeric = {c: describe_numeric(df[c]) for c in num_cols}
    categorical = {c: describe_categorical(df[c]) for c in cat_cols}

    # wartości do wykresów (próbkowanie, gdy dużo danych)
    sample = num_df if len(num_df) <= max_points else num_df.sample(max_points, random_state=42)
    values = {c: [_f(v) for v in sample[c].to_numpy()] for c in num_cols}

    total_cells = df.size
    missing_cells = int(df.isna().sum().sum())
    preview = df.head(15).astype(object).where(df.head(15).notna(), None)

    return {
        "rows": int(len(df)),
        "cols": int(df.shape[1]),
        "numeric_columns": num_cols,
        "categorical_columns": cat_cols,
        "missing_pct": missing_cells / total_cells * 100 if total_cells else 0.0,
        "outliers_total": int(sum(v.get("outliery_iqr", 0) for v in numeric.values())),
        "numeric": numeric,
        "categorical": categorical,
        "measures": [{"key": k, "label": l, "hint": h} for k, l, h in MEASURES],
        "corr_pearson": _corr(num_df, "pearson"),
        "corr_spearman": _corr(num_df, "spearman"),
        "values": values,
        "sampled": len(num_df) > max_points,
        "preview": {"columns": list(df.columns),
                    "rows": [[(_f(v) if isinstance(v, (int, float, np.number)) else (None if v is None else str(v)))
                              for v in row] for row in preview.to_numpy().tolist()]},
    }


def fmt_num(v: Any, digits: int = 4) -> str:
    """Polski format liczby: przecinek dziesiętny, spacja tysięcy."""
    if v is None:
        return "—"
    if isinstance(v, (int, np.integer)) or (isinstance(v, float) and v.is_integer() and abs(v) < 1e15):
        s = f"{int(v):,}".replace(",", " ")
        return s
    a = abs(v)
    if a != 0 and (a < 1e-4 or a >= 1e12):
        return f"{v:.3e}".replace(".", ",")
    d = digits if a < 1000 else 2
    s = f"{v:,.{d}f}".rstrip("0").rstrip(".")
    s = s.replace(",", " ").replace(".", ",")
    return "0" if s == "-0" else s
