"""
StatDash – lokalna mini-aplikacja do analizy statystycznej CSV/Excel.

Uruchomienie:  python app.py            (otworzy przeglądarkę na http://127.0.0.1:5050)
Opcje:         python app.py --port 8080 --no-browser
"""
from __future__ import annotations

import argparse
import html
import os
import re
import threading
import uuid
import webbrowser
from datetime import datetime
from io import BytesIO

from flask import Flask, jsonify, render_template, request, send_file

import mailer
from report import build_html, build_pdf, build_xlsx, _insights, _kpis
from stats_engine import analyze, load_table

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(BASE_DIR, "templates"),
            static_folder=os.path.join(BASE_DIR, "static"))
app.config["MAX_CONTENT_LENGTH"] = 60 * 1024 * 1024  # 60 MB (plik + obrazy wykresów)

DATASETS: dict[str, dict] = {}  # id -> {raw, filename, sheet, df, analysis}
MAX_DATASETS = 10


def _store(raw: bytes, filename: str, sheet: str | None = None) -> dict:
    df, sheets = load_table(raw, filename, sheet)
    a = analyze(df)
    ds_id = uuid.uuid4().hex[:12]
    DATASETS[ds_id] = {"raw": raw, "filename": filename, "sheet": sheet or (sheets[0] if sheets else None),
                       "df": df, "analysis": a}
    while len(DATASETS) > MAX_DATASETS:
        DATASETS.pop(next(iter(DATASETS)))
    return {"id": ds_id, "filename": filename, "sheets": sheets,
            "sheet": DATASETS[ds_id]["sheet"], "analysis": a}


def _err(msg: str, code: int = 400):
    return jsonify({"ok": False, "error": msg}), code


def _slug(s: str) -> str:
    s = re.sub(r"[^\w\-]+", "_", s, flags=re.UNICODE).strip("_")
    return s[:60] or "dashboard"


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/upload")
def upload():
    try:
        if "file" in request.files:
            f = request.files["file"]
            raw = f.read()
            if not raw:
                return _err("Wybrany plik jest pusty.")
            return jsonify({"ok": True, **_store(raw, f.filename or "dane.csv")})
        data = request.get_json(silent=True) or {}
        if data.get("text"):
            return jsonify({"ok": True, **_store(data["text"].encode("utf-8"), "wklejone_dane.csv")})
        return _err("Nie przesłano pliku ani tekstu.")
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Nie udało się wczytać danych: {exc}")


@app.post("/api/sheet")
def change_sheet():
    data = request.get_json(force=True)
    ds = DATASETS.get(data.get("id", ""))
    if not ds:
        return _err("Sesja danych wygasła – wczytaj plik ponownie.", 404)
    try:
        return jsonify({"ok": True, **_store(ds["raw"], ds["filename"], data.get("sheet"))})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Nie udało się wczytać arkusza: {exc}")


@app.post("/api/sample")
def sample():
    path = os.path.join(BASE_DIR, "sample_data", "przyklad_sprzedaz.csv")
    with open(path, "rb") as fh:
        return jsonify({"ok": True, **_store(fh.read(), "przyklad_sprzedaz.csv")})


def _build(ds: dict, fmt: str, images: dict, meta: dict) -> tuple[str, bytes, str, str]:
    meta = dict(meta or {})
    meta.setdefault("filename", ds["filename"] + (f" [{ds['sheet']}]" if ds.get("sheet") else ""))
    base = _slug(meta.get("title") or "dashboard") + "_" + datetime.now().strftime("%Y%m%d_%H%M")
    a = ds["analysis"]
    if fmt == "html":
        return base + ".html", build_html(a, images, meta), "text", "html"
    if fmt == "pdf":
        return base + ".pdf", build_pdf(a, images, meta), "application", "pdf"
    if fmt == "xlsx":
        return (base + "_statystyki.xlsx", build_xlsx(a, ds["df"]), "application",
                "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    raise ValueError("Nieznany format")


@app.post("/api/export")
def export():
    data = request.get_json(force=True)
    ds = DATASETS.get(data.get("id", ""))
    if not ds:
        return _err("Sesja danych wygasła – wczytaj plik ponownie.", 404)
    try:
        name, blob, mt, st = _build(ds, data.get("format", "html"), data.get("images") or {}, data.get("meta") or {})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Błąd generowania raportu: {exc}", 500)
    return send_file(BytesIO(blob), mimetype=f"{mt}/{st}", as_attachment=True, download_name=name)


@app.get("/api/smtp")
def smtp_get():
    return jsonify({"ok": True, "config": mailer.load_config(), "presets": mailer.PRESETS})


@app.post("/api/smtp")
def smtp_save():
    try:
        return jsonify({"ok": True, "config": mailer.save_config(request.get_json(force=True))})
    except ValueError as exc:
        return _err(str(exc))


@app.post("/api/smtp/test")
def smtp_test():
    ok, msg = mailer.test_connection()
    return jsonify({"ok": ok, "message" if ok else "error": msg})


def _mail_html(a: dict, title: str, message: str) -> str:
    e = html.escape
    kpis = "".join(f"<td style='padding:8px 14px;border:1px solid #e1e0d9'><div style='color:#52514e;font-size:12px'>{e(k)}</div>"
                   f"<div style='font-size:18px;font-weight:600'>{e(v)}</div></td>" for k, v in _kpis(a))
    ins = "".join(f"<li>{e(i)}</li>" for i in _insights(a)[:5])
    msg_html = "<br>".join(e(line) for line in (message or "").splitlines())
    return (f"<div style='font-family:Segoe UI,Arial,sans-serif;color:#0b0b0b;font-size:14px'>"
            f"<p>{msg_html}</p><h2 style='font-size:17px'>{e(title)}</h2>"
            f"<table style='border-collapse:collapse'><tr>{kpis}</tr></table>"
            + (f"<p style='margin-top:14px'><b>Najważniejsze obserwacje:</b></p><ul>{ins}</ul>" if ins else "")
            + "<p style='color:#898781;font-size:12px'>Pełny dashboard w załączniku. Wygenerowano w StatDash.</p></div>")


@app.post("/api/send")
def send():
    data = request.get_json(force=True)
    ds = DATASETS.get(data.get("id", ""))
    if not ds:
        return _err("Sesja danych wygasła – wczytaj plik ponownie.", 404)
    to = [t.strip() for t in re.split(r"[,;\s]+", data.get("to", "")) if t.strip()]
    formats = [f for f in data.get("formats", ["html"]) if f in ("html", "pdf", "xlsx")] or ["html"]
    meta = data.get("meta") or {}
    title = meta.get("title") or "Dashboard statystyczny"
    try:
        atts = [_build(ds, f, data.get("images") or {}, meta) for f in formats]
    except Exception as exc:  # noqa: BLE001
        return _err(f"Błąd generowania załączników: {exc}", 500)
    message = data.get("message") or ""
    text = (message + "\n\n" if message else "") + f"W załączniku: {title} ({', '.join(a[0] for a in atts)})."
    ok, msg = mailer.send_mail(to, data.get("subject") or title, text, _mail_html(ds["analysis"], title, message), atts)
    return jsonify({"ok": ok, "message" if ok else "error": msg})


def main():
    p = argparse.ArgumentParser(description="StatDash – lokalny dashboard statystyczny")
    p.add_argument("--port", type=int, default=int(os.environ.get("STATDASH_PORT", 5050)))
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--no-browser", action="store_true")
    args = p.parse_args()
    url = f"http://{args.host}:{args.port}"
    print(f"\n  StatDash działa: {url}\n  Zatrzymanie: Ctrl+C\n")
    import logging
    import flask.cli
    logging.getLogger("werkzeug").setLevel(logging.ERROR)  # bez technicznych komunikatów w konsoli
    flask.cli.show_server_banner = lambda *a, **k: None
    if not args.no_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
