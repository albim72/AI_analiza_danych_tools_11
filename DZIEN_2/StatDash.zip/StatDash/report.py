"""
StatDash – budowa raportu (dashboard) w formatach HTML, PDF i XLSX.
Obrazy wykresów przychodzą z przeglądarki jako PNG (data URL / base64).
"""
from __future__ import annotations

import base64
import html
import io
import os
from datetime import datetime
from typing import Any

import pandas as pd

from stats_engine import MEASURES, fmt_num


def fmt_measure(key: str, v: Any) -> str:
    if key == "jb_p" and v is not None and v < 0.0001:
        return "< 0,0001"
    return fmt_num(v)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(BASE_DIR, "fonts")

CHART_TITLES = {
    "hist": "Histogram",
    "box": "Wykres pudełkowy",
    "scatter": "Wykres rozrzutu z regresją",
    "corr": "Macierz korelacji",
}


def _png_bytes(data_url: str) -> bytes:
    if "," in data_url:
        data_url = data_url.split(",", 1)[1]
    return base64.b64decode(data_url)


def _kpis(a: dict[str, Any]) -> list[tuple[str, str]]:
    return [
        ("Wiersze", fmt_num(a["rows"])),
        ("Kolumny liczbowe", fmt_num(len(a["numeric_columns"]))),
        ("Kolumny tekstowe", fmt_num(len(a["categorical_columns"]))),
        ("Braki danych", fmt_num(a["missing_pct"], 2) + " %"),
        ("Obserwacje odstające (IQR)", fmt_num(a["outliers_total"])),
    ]


def _insights(a: dict[str, Any]) -> list[str]:
    """Krótkie, automatyczne wnioski tekstowe."""
    out = []
    for c in a["numeric_columns"]:
        s = a["numeric"][c]
        if not s.get("n"):
            continue
        sk = s.get("skosnosc")
        if sk is not None and abs(sk) >= 1:
            out.append(f"„{c}” ma silnie {'prawo' if sk > 0 else 'lewo'}stronnie skośny rozkład (skośność {fmt_num(sk, 2)}) – mediana ({fmt_num(s['mediana'])}) lepiej opisuje typową wartość niż średnia ({fmt_num(s['srednia'])}).")
        cv = s.get("wsp_zmiennosci_proc")
        if cv is not None and cv > 50:
            out.append(f"„{c}” ma dużą zmienność (współczynnik zmienności {fmt_num(cv, 1)} %).")
        if s.get("outliery_iqr", 0) > 0 and s["n"] and s["outliery_iqr"] / s["n"] > 0.05:
            out.append(f"„{c}”: {s['outliery_iqr']} obserwacji odstających ({fmt_num(s['outliery_iqr'] / s['n'] * 100, 1)} %).")
    cols = a["numeric_columns"]
    pairs = []
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            r = a["corr_pearson"][i][j] if a["corr_pearson"] else None
            if r is not None and abs(r) >= 0.6:
                pairs.append((abs(r), r, cols[i], cols[j]))
    for _, r, c1, c2 in sorted(pairs, reverse=True)[:4]:
        out.append(f"Silna korelacja {'dodatnia' if r > 0 else 'ujemna'} między „{c1}” a „{c2}” (r = {fmt_num(r, 3)}).")
    return out[:10]


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------

def build_html(a: dict[str, Any], images: dict[str, str], meta: dict[str, Any]) -> bytes:
    e = html.escape
    title = meta.get("title") or "Dashboard statystyczny"
    created = datetime.now().strftime("%d.%m.%Y %H:%M")
    kpi_html = "".join(f'<div class="kpi"><div class="kl">{e(k)}</div><div class="kv">{e(v)}</div></div>' for k, v in _kpis(a))

    charts = ""
    for key in ("hist", "box", "scatter", "corr"):
        if images.get(key):
            sub = e(meta.get("captions", {}).get(key, ""))
            charts += (f'<figure class="card"><figcaption><b>{CHART_TITLES[key]}</b>'
                       f'<span>{sub}</span></figcaption><img src="{images[key]}" alt="{CHART_TITLES[key]}"></figure>')

    cols = a["numeric_columns"]
    head = "".join(f"<th>{e(c)}</th>" for c in cols)
    rows = ""
    for key, label, hint in MEASURES:
        cells = "".join(f"<td>{e(fmt_measure(key, a['numeric'][c].get(key)))}</td>" for c in cols)
        rows += f'<tr><th title="{e(hint)}">{e(label)}</th>{cells}</tr>'
    stats_table = f'<div class="tw"><table><thead><tr><th>Miara</th>{head}</tr></thead><tbody>{rows}</tbody></table></div>' if cols else "<p>Brak kolumn liczbowych.</p>"

    corr_html = ""
    if a["corr_pearson"]:
        h = "".join(f"<th>{e(c)}</th>" for c in cols)
        r = ""
        for i, c in enumerate(cols):
            r += f"<tr><th>{e(c)}</th>" + "".join(f"<td>{e(fmt_num(v, 3))}</td>" for v in a["corr_pearson"][i]) + "</tr>"
        corr_html = f'<h2>Korelacje Pearsona</h2><div class="tw"><table><thead><tr><th></th>{h}</tr></thead><tbody>{r}</tbody></table></div>'

    cat_html = ""
    if a["categorical_columns"]:
        items = ""
        for c in a["categorical_columns"]:
            d = a["categorical"][c]
            tops = ", ".join(f"{e(t['wartosc'])} ({t['liczba']})" for t in d["top"])
            items += f"<tr><th>{e(c)}</th><td>{d['n']}</td><td>{d['braki']}</td><td>{d['unikalne']}</td><td>{tops}</td></tr>"
        cat_html = ("<h2>Kolumny tekstowe / kategorie</h2><div class='tw'><table><thead><tr><th>Kolumna</th><th>N</th>"
                    "<th>Braki</th><th>Unikalne</th><th>Najczęstsze wartości</th></tr></thead><tbody>" + items + "</tbody></table></div>")

    ins = _insights(a)
    ins_html = ("<h2>Najważniejsze obserwacje</h2><ul class='ins'>" + "".join(f"<li>{e(i)}</li>" for i in ins) + "</ul>") if ins else ""

    doc = f"""<!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)}</title>
<style>
:root{{--s:#fcfcfb;--p:#f9f9f7;--t1:#0b0b0b;--t2:#52514e;--mu:#898781;--g:#e1e0d9;--b:rgba(11,11,11,.10);--acc:#2a78d6}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--p);color:var(--t1);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
.wrap{{max-width:1200px;margin:0 auto;padding:28px 24px 48px}}
header{{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;border-bottom:1px solid var(--g);padding-bottom:14px;margin-bottom:20px}}
h1{{margin:0;font-size:24px}}.meta{{color:var(--t2);font-size:13px;text-align:right}}
h2{{font-size:16px;margin:28px 0 10px}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}}
.kpi{{background:var(--s);border:1px solid var(--b);border-radius:10px;padding:12px 14px}}.kl{{color:var(--t2);font-size:12px}}.kv{{font-size:24px;font-weight:600}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(480px,1fr));gap:14px;margin-top:16px}}
.card{{margin:0;background:var(--s);border:1px solid var(--b);border-radius:10px;padding:14px}}
figcaption{{display:flex;flex-direction:column;margin-bottom:8px}}figcaption span{{color:var(--t2);font-size:12px}}
.card img{{width:100%;height:auto;display:block}}
.tw{{overflow-x:auto;background:var(--s);border:1px solid var(--b);border-radius:10px}}
table{{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:13px}}
th,td{{padding:6px 10px;border-bottom:1px solid var(--g);text-align:right;white-space:nowrap}}
th:first-child{{text-align:left;color:var(--t2);font-weight:500}}thead th{{background:#f0efec;color:var(--t1);font-weight:600}}
td:last-child{{white-space:normal}}
.ins li{{margin:4px 0}}footer{{margin-top:32px;color:var(--mu);font-size:12px}}
@media print{{.grid{{grid-template-columns:1fr 1fr}}body{{background:#fff}}}}
</style></head><body><div class="wrap">
<header><div><h1>{e(title)}</h1><div style="color:var(--t2)">Źródło danych: {e(meta.get('filename') or '—')}</div></div>
<div class="meta">Wygenerowano: {created}<br>StatDash</div></header>
<div class="kpis">{kpi_html}</div>
{ins_html}
<div class="grid">{charts}</div>
<h2>Statystyki opisowe</h2>{stats_table}
{corr_html}
{cat_html}
<footer>Odchylenie standardowe i wariancja liczone z próby (n−1). Percentyle metodą interpolacji liniowej (jak PERCENTYL.PRZEDZ.ZAMK w Excelu). Raport wygenerowany lokalnie przez StatDash.</footer>
</div></body></html>"""
    return doc.encode("utf-8")


# ---------------------------------------------------------------------------
# PDF (reportlab)
# ---------------------------------------------------------------------------

def build_pdf(a: dict[str, Any], images: dict[str, str], meta: dict[str, Any]) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import (Image, PageBreak, Paragraph, SimpleDocTemplate,
                                    Spacer, Table, TableStyle)

    try:
        pdfmetrics.registerFont(TTFont("DejaVu", os.path.join(FONT_DIR, "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DejaVu-Bold", os.path.join(FONT_DIR, "DejaVuSans-Bold.ttf")))
        F, FB = "DejaVu", "DejaVu-Bold"
    except Exception:  # brak czcionek – polskie znaki mogą się nie wyświetlić
        F, FB = "Helvetica", "Helvetica-Bold"

    ink, ink2, grid = colors.HexColor("#0b0b0b"), colors.HexColor("#52514e"), colors.HexColor("#e1e0d9")
    st_t = ParagraphStyle("t", fontName=FB, fontSize=18, leading=22, textColor=ink)
    st_h = ParagraphStyle("h", fontName=FB, fontSize=12, leading=16, spaceBefore=8, spaceAfter=4, textColor=ink)
    st_p = ParagraphStyle("p", fontName=F, fontSize=9, leading=12, textColor=ink2)
    st_c = ParagraphStyle("c", fontName=F, fontSize=7.5, leading=9, textColor=ink)
    st_cr = ParagraphStyle("cr", parent=st_c, alignment=2)

    buf = io.BytesIO()
    page = landscape(A4)
    doc = SimpleDocTemplate(buf, pagesize=page, leftMargin=12 * mm, rightMargin=12 * mm,
                            topMargin=12 * mm, bottomMargin=12 * mm,
                            title=meta.get("title") or "Dashboard statystyczny", author="StatDash")
    W = page[0] - 24 * mm
    story: list[Any] = []
    title = meta.get("title") or "Dashboard statystyczny"
    story.append(Paragraph(html.escape(title), st_t))
    story.append(Paragraph(f"Źródło: {html.escape(meta.get('filename') or '—')} · wygenerowano {datetime.now():%d.%m.%Y %H:%M}", st_p))
    story.append(Spacer(1, 6))

    kp = _kpis(a)
    kt = Table([[Paragraph(k, st_p) for k, _ in kp], [Paragraph(f"<font name='{FB}' size='15'>{v}</font>", st_c) for _, v in kp]],
               colWidths=[W / len(kp)] * len(kp), rowHeights=[14, 26])
    kt.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.5, grid), ("INNERGRID", (0, 0), (-1, -1), 0.5, grid),
                            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fcfcfb"))]))
    story.append(kt)


    # wykresy 2×2
    imgs = []
    for key in ("hist", "box", "scatter", "corr"):
        if images.get(key):
            raw = _png_bytes(images[key])
            iw, ih = ImageReader(io.BytesIO(raw)).getSize()
            w = W / 2 - 4 * mm
            h = min(w * ih / iw, 52 * mm)
            w = h * iw / ih
            cap = meta.get("captions", {}).get(key, "")
            imgs.append([Paragraph(f"<font name='{FB}' color='#0b0b0b'>{CHART_TITLES[key]}</font><br/>{html.escape(cap)}", st_p),
                         Image(io.BytesIO(raw), width=w, height=h)])
    if imgs:
        story.append(Spacer(1, 6))
        cells = [[c for c in imgs[i:i + 2]] for i in range(0, len(imgs), 2)]
        for row in cells:
            if len(row) == 1:
                row.append("")
        gt = Table(cells, colWidths=[W / 2, W / 2])
        gt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
        story.append(gt)

    # tabela statystyk – po max 7 kolumn na blok
    cols = a["numeric_columns"]
    story.append(PageBreak())
    ins = _insights(a)
    if ins:
        story.append(Paragraph("Najważniejsze obserwacje", st_h))
        for i in ins[:8]:
            story.append(Paragraph("• " + html.escape(i), st_p))
        story.append(Spacer(1, 6))
    if cols:
        story.append(Paragraph("Statystyki opisowe", st_h))
        per = 7
        for start in range(0, len(cols), per):
            chunk = cols[start:start + per]
            data = [[Paragraph(f"<font name='{FB}'>Miara</font>", st_c)] + [Paragraph(f"<font name='{FB}'>{html.escape(c)}</font>", st_cr) for c in chunk]]
            for key, label, _ in MEASURES:
                data.append([Paragraph(label, st_c)] + [fmt_measure(key, a["numeric"][c].get(key)) for c in chunk])
            first = 62 * mm
            other = (W - first) / per
            t = Table(data, colWidths=[first] + [other] * len(chunk), repeatRows=1)
            t.setStyle(TableStyle([
                ("FONTNAME", (0, 0), (-1, -1), F), ("FONTSIZE", (0, 0), (-1, -1), 7.5),
                ("ALIGN", (1, 1), (-1, -1), "RIGHT"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LINEBELOW", (0, 0), (-1, -1), 0.3, grid), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f0efec")),
                ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5),
            ]))
            story.append(t)
            story.append(Spacer(1, 8))

    if a["categorical_columns"]:
        story.append(Paragraph("Kolumny tekstowe / kategorie", st_h))
        data = [[Paragraph(f"<font name='{FB}'>{h}</font>", st_c) for h in ("Kolumna", "N", "Braki", "Unikalne", "Najczęstsze wartości")]]
        for c in a["categorical_columns"]:
            d = a["categorical"][c]
            tops = ", ".join(f"{t['wartosc']} ({t['liczba']})" for t in d["top"])
            data.append([Paragraph(html.escape(c), st_c), d["n"], d["braki"], d["unikalne"], Paragraph(html.escape(tops), st_c)])
        t = Table(data, colWidths=[50 * mm, 18 * mm, 18 * mm, 20 * mm, W - 106 * mm], repeatRows=1)
        t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), F), ("FONTSIZE", (0, 0), (-1, -1), 7.5),
                               ("LINEBELOW", (0, 0), (-1, -1), 0.3, grid), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f0efec"))]))
        story.append(t)

    def _footer(canvas, _doc):
        canvas.saveState()
        canvas.setFont(F, 7)
        canvas.setFillColor(ink2)
        canvas.drawRightString(page[0] - 12 * mm, 7 * mm, f"StatDash · strona {_doc.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# XLSX
# ---------------------------------------------------------------------------

def build_xlsx(a: dict[str, Any], df: pd.DataFrame) -> bytes:
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    cols = a["numeric_columns"]
    stats = pd.DataFrame(
        {c: [a["numeric"][c].get(k) for k, _, _ in MEASURES] for c in cols},
        index=[l for _, l, _ in MEASURES],
    )
    stats.index.name = "Miara"
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        stats.to_excel(xw, sheet_name="Statystyki")
        if a["corr_pearson"]:
            pd.DataFrame(a["corr_pearson"], index=cols, columns=cols).to_excel(xw, sheet_name="Korelacje Pearson")
            pd.DataFrame(a["corr_spearman"], index=cols, columns=cols).to_excel(xw, sheet_name="Korelacje Spearman")
        if a["categorical_columns"]:
            rows = []
            for c in a["categorical_columns"]:
                d = a["categorical"][c]
                for t in d["top"]:
                    rows.append({"Kolumna": c, "Wartość": t["wartosc"], "Liczba": t["liczba"], "Udział %": round(t["proc"], 2)})
            pd.DataFrame(rows).to_excel(xw, sheet_name="Kategorie", index=False)
        df.to_excel(xw, sheet_name="Dane", index=False)
        hdr = PatternFill("solid", fgColor="F0EFEC")
        for ws in xw.book.worksheets:
            for cell in ws[1]:
                cell.font = Font(bold=True)
                cell.fill = hdr
            ws.freeze_panes = "B2"
            for i, col in enumerate(ws.columns, 1):
                width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
                ws.column_dimensions[get_column_letter(i)].width = min(max(10, width + 2), 45)
            for row in ws.iter_rows(min_row=2, min_col=2):
                for c in row:
                    if isinstance(c.value, float):
                        c.number_format = "0.0000"
                        c.alignment = Alignment(horizontal="right")
    return buf.getvalue()
