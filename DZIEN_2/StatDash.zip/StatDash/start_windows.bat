@echo off
chcp 65001 >nul
title StatDash
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo.
  echo  Nie znaleziono Pythona. Zainstaluj Python 3.10+ ze strony https://www.python.org/downloads/
  echo  ^(podczas instalacji zaznacz "Add Python to PATH"^), a potem uruchom ten plik ponownie.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Tworze srodowisko Pythona ^(tylko przy pierwszym uruchomieniu^)...
  %PY% -m venv .venv || (echo Blad tworzenia srodowiska & pause & exit /b 1)
)

echo Sprawdzam biblioteki...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt || (echo Blad instalacji bibliotek & pause & exit /b 1)

echo.
echo  StatDash startuje - przegladarka otworzy sie automatycznie.
echo  Aby zakonczyc, zamknij to okno.
echo.
".venv\Scripts\python.exe" app.py
pause
