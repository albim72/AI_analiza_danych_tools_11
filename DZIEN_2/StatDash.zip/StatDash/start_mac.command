#!/usr/bin/env bash
# StatDash – uruchomienie na macOS / Linux
set -e
cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else
  echo "Nie znaleziono Pythona 3. Zainstaluj go: https://www.python.org/downloads/"; exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "Tworzę środowisko Pythona (tylko przy pierwszym uruchomieniu)..."
  "$PY" -m venv .venv
fi

echo "Sprawdzam biblioteki..."
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt

echo
echo "  StatDash startuje – przeglądarka otworzy się automatycznie."
echo "  Aby zakończyć: Ctrl+C"
echo
exec .venv/bin/python app.py "$@"
