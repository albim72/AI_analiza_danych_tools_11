/* StatDash – logika interfejsu */
(() => {
  "use strict";

  // ---------- paleta (role, nie kolory "na oko") ----------
  const C = {
    surface: "#fcfcfb", t1: "#0b0b0b", t2: "#52514e", muted: "#898781",
    grid: "#e1e0d9", axis: "#c3c2b7",
    s1: "#2a78d6", s1a: "rgba(42,120,214,0.22)", s2: "#eb6834",
    divNeg: [184, 48, 47], divMid: [240, 239, 236], divPos: [28, 92, 171],
  };

  // ---------- Chart.js – rejestracja i ustawienia ----------
  const reg = (...xs) => { try { Chart.register(...xs.filter(Boolean)); } catch (e) { /* już zarejestrowane */ } };
  if (window.ChartBoxPlot) reg(ChartBoxPlot.BoxPlotController, ChartBoxPlot.BoxAndWiskers);
  if (window["chartjs-chart-matrix"]) reg(window["chartjs-chart-matrix"].MatrixController, window["chartjs-chart-matrix"].MatrixElement);

  Chart.defaults.font.family = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  Chart.defaults.font.size = 12;
  Chart.defaults.color = C.t2;
  Chart.defaults.borderColor = C.grid;
  Chart.defaults.devicePixelRatio = Math.max(2, window.devicePixelRatio || 1);
  Chart.defaults.maintainAspectRatio = false;
  Chart.defaults.animation.duration = 350;
  Object.assign(Chart.defaults.plugins.tooltip, {
    backgroundColor: "#ffffff", titleColor: C.t1, bodyColor: C.t2, borderColor: "rgba(11,11,11,.12)",
    borderWidth: 1, padding: 10, cornerRadius: 8, boxPadding: 4, titleFont: { weight: "600" },
  });
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.boxHeight = 8;
  Chart.defaults.plugins.legend.position = "top";
  Chart.defaults.plugins.legend.align = "end";

  // tło pod eksport PNG
  Chart.register({
    id: "surfaceBg",
    beforeDraw(chart) {
      const { ctx, width, height } = chart;
      ctx.save(); ctx.fillStyle = C.surface; ctx.fillRect(0, 0, width, height); ctx.restore();
    },
  });

  // ---------- pomocnicze ----------
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nf = (d = 4) => new Intl.NumberFormat("pl-PL", { maximumFractionDigits: d });
  const fmt = (v, d = 4) => {
    if (v === null || v === undefined || Number.isNaN(v)) return "—";
    const a = Math.abs(v);
    if (a !== 0 && (a < 1e-4 || a >= 1e12)) return v.toExponential(3).replace(".", ",");
    const out = nf(a >= 1000 ? 2 : d).format(v);
    return /^[-−]0$/.test(out) ? "0" : out;
  };
  const fmtMeasure = (key, v) => (key === "jb_p" && v !== null && v < 1e-4 ? "< 0,0001" : fmt(v));
  const short = (s, n = 16) => (s.length > n ? s.slice(0, n - 1) + "…" : s);
  const loader = (on) => $("#loader").classList.toggle("hidden", !on);
  const status = (el, kind, msg) => { el.innerHTML = msg ? `<div class="status ${kind}">${esc(msg)}</div>` : ""; };

  async function api(url, body, opts = {}) {
    const init = { method: body === undefined ? "GET" : "POST", ...opts };
    if (body instanceof FormData) init.body = body;
    else if (body !== undefined) { init.body = JSON.stringify(body); init.headers = { "Content-Type": "application/json" }; }
    const r = await fetch(url, init);
    if (opts.raw) return r;
    let j;
    try { j = await r.json(); } catch { throw new Error(`Błąd serwera (${r.status}).`); }
    if (!r.ok && j.ok === undefined) throw new Error(j.error || `Błąd serwera (${r.status}).`);
    return j;
  }

  // ---------- stan ----------
  let DS = null; // { id, filename, sheets, sheet, analysis }
  const charts = {};

  // ---------- wczytywanie ----------
  const drop = $("#drop");
  ["dragenter", "dragover"].forEach((e) => drop.addEventListener(e, (ev) => { ev.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach((e) => drop.addEventListener(e, (ev) => { ev.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", (ev) => { const f = ev.dataTransfer.files[0]; if (f) uploadFile(f); });
  $("#fileInput").addEventListener("change", (ev) => { const f = ev.target.files[0]; if (f) uploadFile(f); ev.target.value = ""; });
  $("#btnSample").addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); load(() => api("/api/sample", {})); });
  $("#btnPaste").addEventListener("click", () => {
    const text = $("#pasteArea").value.trim();
    if (!text) return status($("#uploadStatus"), "err", "Wklej najpierw dane (z nagłówkiem w pierwszym wierszu).");
    load(() => api("/api/upload", { text }));
  });
  $("#btnNew").addEventListener("click", () => {
    $("#dashView").classList.add("hidden"); $("#uploadView").classList.remove("hidden");
    $("#btnNew").classList.add("hidden"); $("#dsName").textContent = ""; window.scrollTo(0, 0);
  });
  $("#sheetSel").addEventListener("change", (ev) => load(() => api("/api/sheet", { id: DS.id, sheet: ev.target.value })));

  function uploadFile(f) {
    if (f.size > 50 * 1024 * 1024) return status($("#uploadStatus"), "err", "Plik jest większy niż 50 MB.");
    const fd = new FormData(); fd.append("file", f);
    load(() => api("/api/upload", fd));
  }

  async function load(fn) {
    loader(true); status($("#uploadStatus"), "", "");
    try {
      const j = await fn();
      if (!j.ok) throw new Error(j.error);
      DS = j; render();
    } catch (e) {
      status($("#uploadStatus"), "err", e.message);
    } finally { loader(false); }
  }

  // ---------- render dashboardu ----------
  function render() {
    const a = DS.analysis;
    $("#uploadView").classList.add("hidden"); $("#dashView").classList.remove("hidden"); $("#btnNew").classList.remove("hidden");
    $("#dsName").textContent = "· " + DS.filename + (DS.sheet ? ` [${DS.sheet}]` : "");
    const base = DS.filename.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ");
    $("#dashTitle").value = `Analiza statystyczna – ${base}`;
    if (!$("#mailSubj").dataset.touched) $("#mailSubj").value = $("#dashTitle").value;

    // arkusze
    $("#sheetField").classList.toggle("hidden", !(DS.sheets && DS.sheets.length > 1));
    $("#sheetSel").innerHTML = (DS.sheets || []).map((s) => `<option ${s === DS.sheet ? "selected" : ""}>${esc(s)}</option>`).join("");

    // KPI
    const kp = [
      ["Wiersze", nf(0).format(a.rows), a.sampled ? "wykresy na próbie 20 000" : `${a.cols} kolumn`],
      ["Kolumny liczbowe", a.numeric_columns.length, "analizowane statystycznie"],
      ["Kolumny tekstowe", a.categorical_columns.length, "zliczenia kategorii"],
      ["Braki danych", fmt(a.missing_pct, 2) + " %", "pustych komórek"],
      ["Obserwacje odstające", nf(0).format(a.outliers_total), "reguła 1,5·IQR, łącznie"],
    ];
    $("#kpis").innerHTML = kp.map(([l, v, h]) => `<div class="kpi"><div class="kl">${l}</div><div class="kv">${esc(v)}</div><div class="kh">${h}</div></div>`).join("");

    // selektory
    const nc = a.numeric_columns;
    const opts = (sel) => nc.map((c) => `<option value="${esc(c)}" ${c === sel ? "selected" : ""}>${esc(c)}</option>`).join("");
    const [best1, best2] = strongestPair(a);
    $("#histCol").innerHTML = opts(nc[0]);
    $("#scX").innerHTML = opts(best1);
    $("#scY").innerHTML = opts(best2);
    $("#boxStd").checked = nc.length > 1 && scalesDiffer(a);

    renderInsights(); renderStats(); renderCats(); renderPreview();
    drawAll();
    refreshSmtpState();
    window.scrollTo(0, 0);
  }

  function strongestPair(a) {
    const nc = a.numeric_columns, m = a.corr_pearson;
    if (nc.length < 2) return [nc[0], nc[0]];
    let best = [0, 1, -1];
    for (let i = 0; i < nc.length; i++) for (let j = i + 1; j < nc.length; j++) {
      const r = m[i][j]; if (r !== null && Math.abs(r) > best[2]) best = [i, j, Math.abs(r)];
    }
    return [nc[best[0]], nc[best[1]]];
  }
  function scalesDiffer(a) {
    const r = a.numeric_columns.map((c) => a.numeric[c].iqr || a.numeric[c].rozstep || 0).filter((x) => x > 0);
    return r.length > 1 && Math.max(...r) / Math.min(...r) > 4;
  }

  function insightsList() {
    const a = DS.analysis, out = [];
    for (const c of a.numeric_columns) {
      const s = a.numeric[c]; if (!s.n) continue;
      if (s.skosnosc !== null && Math.abs(s.skosnosc) >= 1)
        out.push(`„${c}” ma silnie ${s.skosnosc > 0 ? "prawo" : "lewo"}stronnie skośny rozkład (skośność ${fmt(s.skosnosc, 2)}) – mediana (${fmt(s.mediana)}) lepiej opisuje typową wartość niż średnia (${fmt(s.srednia)}).`);
      if (s.wsp_zmiennosci_proc !== null && s.wsp_zmiennosci_proc > 50)
        out.push(`„${c}” ma dużą zmienność (współczynnik zmienności ${fmt(s.wsp_zmiennosci_proc, 1)} %).`);
      if (s.outliery_iqr > 0 && s.outliery_iqr / s.n > 0.05)
        out.push(`„${c}”: ${s.outliery_iqr} obserwacji odstających (${fmt(s.outliery_iqr / s.n * 100, 1)} %).`);
    }
    const nc = a.numeric_columns, pairs = [];
    for (let i = 0; i < nc.length; i++) for (let j = i + 1; j < nc.length; j++) {
      const r = a.corr_pearson[i]?.[j]; if (r !== null && r !== undefined && Math.abs(r) >= 0.6) pairs.push([Math.abs(r), r, nc[i], nc[j]]);
    }
    pairs.sort((x, y) => y[0] - x[0]).slice(0, 4).forEach(([, r, c1, c2]) =>
      out.push(`Silna korelacja ${r > 0 ? "dodatnia" : "ujemna"} między „${c1}” a „${c2}” (r = ${fmt(r, 3)}).`));
    return out.slice(0, 10);
  }
  function renderInsights() {
    const ins = insightsList();
    $("#insightsCard").classList.toggle("hidden", !ins.length);
    $("#insights").innerHTML = ins.map((i) => `<li>${esc(i)}</li>`).join("");
  }

  function renderStats() {
    const a = DS.analysis, nc = a.numeric_columns;
    if (!nc.length) { $("#statsTable").innerHTML = "<tbody><tr><th>Brak kolumn liczbowych w danych.</th></tr></tbody>"; return; }
    const head = `<thead><tr><th>Miara</th>${nc.map((c) => `<th title="${esc(c)}">${esc(short(c, 22))}</th>`).join("")}</tr></thead>`;
    const body = a.measures.map((m) =>
      `<tr><th>${m.hint ? `<span class="hint" title="${esc(m.hint)}">${esc(m.label)}</span>` : esc(m.label)}</th>` +
      nc.map((c) => `<td>${esc(fmtMeasure(m.key, a.numeric[c][m.key]))}</td>`).join("") + "</tr>").join("");
    $("#statsTable").innerHTML = head + "<tbody>" + body + "</tbody>";
  }
  $("#btnCopy").addEventListener("click", async () => {
    const a = DS.analysis, nc = a.numeric_columns;
    const lines = [["Miara", ...nc].join("\t"), ...a.measures.map((m) => [m.label, ...nc.map((c) => {
      const v = a.numeric[c][m.key]; return v === null || v === undefined ? "" : String(v).replace(".", ",");
    })].join("\t"))];
    try { await navigator.clipboard.writeText(lines.join("\n")); $("#btnCopy").textContent = "✓ Skopiowano – wklej do Excela"; }
    catch { $("#btnCopy").textContent = "Nie udało się skopiować"; }
    setTimeout(() => ($("#btnCopy").textContent = "⧉ Kopiuj tabelę"), 2500);
  });

  function renderCats() {
    const a = DS.analysis, cc = a.categorical_columns;
    $("#catSection").classList.toggle("hidden", !cc.length);
    if (!cc.length) return;
    $("#catTable").innerHTML = "<thead><tr><th>Kolumna</th><th>N</th><th>Braki</th><th>Unikalne</th><th style='text-align:left'>Najczęstsze wartości (liczba, udział)</th></tr></thead><tbody>" +
      cc.map((c) => { const d = a.categorical[c]; return `<tr><th>${esc(c)}</th><td>${d.n}</td><td>${d.braki}</td><td>${d.unikalne}</td><td class="txt">${d.top.map((t) => `${esc(t.wartosc)} <span style="color:var(--muted)">(${t.liczba}, ${fmt(t.proc, 1)} %)</span>`).join(" · ")}</td></tr>`; }).join("") + "</tbody>";
  }

  function renderPreview() {
    const p = DS.analysis.preview;
    $("#previewSub").textContent = `Pierwsze ${p.rows.length} z ${nf(0).format(DS.analysis.rows)} wierszy.`;
    const isNum = p.columns.map((c) => DS.analysis.numeric_columns.includes(c));
    $("#previewTable").innerHTML = `<thead><tr><th>#</th>${p.columns.map((c, i) => `<th class="${isNum[i] ? "" : "l"}">${esc(c)}</th>`).join("")}</tr></thead><tbody>` +
      p.rows.map((r, i) => `<tr><th>${i + 1}</th>${r.map((v) => typeof v === "number" ? `<td>${fmt(v)}</td>` : `<td class="l">${esc(v ?? "—")}</td>`).join("")}</tr>`).join("") + "</tbody>";
  }

  // ---------- wykresy ----------
  ["#histCol"].forEach((s) => $(s).addEventListener("change", drawHist));
  ["#scX", "#scY"].forEach((s) => $(s).addEventListener("change", drawScatter));
  $("#boxStd").addEventListener("change", drawBox);
  $("#corrMethod").addEventListener("change", drawCorr);

  function drawAll() { drawHist(); drawBox(); drawScatter(); drawCorr(); }
  function mk(key, canvasId, cfg) {
    if (charts[key]) charts[key].destroy();
    const cv = $(canvasId);
    cv.parentElement.querySelector(".empty")?.remove();
    cv.classList.remove("hidden");
    charts[key] = new Chart(cv, cfg);
  }
  function empty(key, canvasId, capId, msg) {
    if (charts[key]) { charts[key].destroy(); delete charts[key]; }
    const cv = $(canvasId); cv.classList.add("hidden");
    if (!cv.parentElement.querySelector(".empty"))
      cv.insertAdjacentHTML("afterend", `<div class="empty sub" style="display:grid;place-items:center;height:100%">${esc(msg)}</div>`);
    $(capId).textContent = "";
  }
  const vals = (c) => DS.analysis.values[c].filter((v) => v !== null);
  const scaleOpts = (title) => ({
    grid: { color: C.grid, drawTicks: false }, border: { color: C.axis },
    ticks: { color: C.muted, padding: 6, callback(v) { return fmt(typeof v === "number" && this.type !== "category" ? v : Number(this.getLabelForValue(v)), 2); } },
    title: title ? { display: true, text: title, color: C.t2 } : undefined,
  });

  // --- histogram + krzywa normalna + linie średniej/mediany
  const refLines = {
    id: "refLines",
    afterDatasetsDraw(chart, _a, o) {
      if (!o || !o.lines) return;
      const { ctx, chartArea: ca, scales: { x } } = chart;
      const p0 = x.getPixelForValue(0), p1 = x.getPixelForValue(1), step = p1 - p0;
      const pos = o.lines.map((l) => p0 + ((l.value - o.lo) / o.bw - 0.5) * step);
      ctx.save();
      o.lines.forEach((l, i) => {
        const px = pos[i]; if (px < ca.left || px > ca.right) return;
        ctx.strokeStyle = l.color; ctx.lineWidth = 1.5; ctx.setLineDash(l.dash || []);
        ctx.beginPath(); ctx.moveTo(px, ca.top); ctx.lineTo(px, ca.bottom); ctx.stroke();
      });
      ctx.setLineDash([]);
      // etykiety obok linii (nad słupkami), z tłem – nie nachodzą na siebie
      ctx.font = "600 11px system-ui, sans-serif";
      const texts = o.lines.map((l) => `${l.label}: ${fmt(l.value, 2)}`);
      const w = Math.max(...texts.map((t) => ctx.measureText(t).width)) + 10;
      const maxPx = Math.max(...pos), minPx = Math.min(...pos);
      const right = maxPx + 6 + w < ca.right;
      const bx = right ? maxPx + 6 : minPx - 6 - w;
      texts.forEach((t, i) => {
        const by = ca.top + 2 + i * 18;
        ctx.fillStyle = "rgba(252,252,251,0.92)"; ctx.fillRect(bx, by, w, 16);
        ctx.fillStyle = o.lines[i].color; ctx.textBaseline = "middle"; ctx.textAlign = "left";
        ctx.fillRect(bx + 3, by + 7, 6, o.lines[i].dash ? 1.5 : 2);
        ctx.fillText(t, bx + 12, by + 8.5);
      });
      ctx.restore();
    },
  };
  function drawHist() {
    const c = $("#histCol").value;
    if (!c) return empty("hist", "#chHist", "#capHist", "Brak kolumn liczbowych.");
    const x = vals(c), s = DS.analysis.numeric[c];
    if (x.length < 2) return empty("hist", "#chHist", "#capHist", "Za mało danych w tej kolumnie.");
    const lo = s.min, hi = s.max, n = x.length;
    let k;
    if (hi === lo) k = 1;
    else {
      const h = 2 * (s.iqr || (hi - lo) / 4) * Math.pow(n, -1 / 3);
      k = Math.min(40, Math.max(6, Math.ceil((hi - lo) / (h || 1))));
    }
    const bw = hi === lo ? 1 : (hi - lo) / k;
    const counts = new Array(k).fill(0);
    x.forEach((v) => { counts[Math.min(k - 1, Math.floor((v - lo) / bw))]++; });
    const labels = counts.map((_, i) => `${fmt(lo + i * bw, 2)} – ${fmt(lo + (i + 1) * bw, 2)}`);
    const sd = s.odch_std || 0;
    const normal = counts.map((_, i) => {
      if (!sd) return null;
      const m = lo + (i + 0.5) * bw;
      return n * bw * Math.exp(-0.5 * ((m - s.srednia) / sd) ** 2) / (sd * Math.sqrt(2 * Math.PI));
    });
    mk("hist", "#chHist", {
      type: "bar",
      data: { labels, datasets: [
        { type: "bar", label: "Liczba obserwacji", data: counts, backgroundColor: C.s1, borderRadius: { topLeft: 4, topRight: 4 }, borderSkipped: "bottom",
          barPercentage: 1, categoryPercentage: 1, borderColor: C.surface, borderWidth: { left: 1, right: 1 }, order: 2 },
        { type: "line", label: "Rozkład normalny (dopasowany)", data: normal, borderColor: C.s2, borderWidth: 2, pointRadius: 0, tension: 0.35, order: 1 },
      ] },
      options: {
        interaction: { mode: "index", intersect: false },
        scales: {
          x: { ...scaleOpts(c), ticks: { color: C.muted, maxRotation: 0, autoSkip: true, maxTicksLimit: 7,
            callback(v) { return fmt(lo + v * bw, 1); } }, grid: { display: false } },
          y: { ...scaleOpts("Liczba obserwacji"), beginAtZero: true, suggestedMax: Math.max(...counts) * 1.22, ticks: { color: C.muted, precision: 0 } },
        },
        plugins: {
          refLines: { lo, bw, lines: [
            { label: "Średnia", value: s.srednia, color: C.t1, dash: [5, 4] },
            { label: "Mediana", value: s.mediana, color: C.t2 },
          ] },
          tooltip: { itemSort: (a, b) => a.datasetIndex - b.datasetIndex, callbacks: {
            title: (it) => `Przedział: ${it[0].label}`,
            label: (it) => it.datasetIndex === 0 ? ` ${it.raw} obs. (${fmt(it.raw / n * 100, 1)} %)` : ` normalny: ${fmt(it.raw, 1)}`,
          } },
        },
      },
      plugins: [refLines],
    });
    $("#capHist").textContent = `${c} · ${k} przedziałów (reguła Freedmana–Diaconisa) · średnia ${fmt(s.srednia, 2)}, mediana ${fmt(s.mediana, 2)}, odch. std ${fmt(sd, 2)}`;
  }

  // --- boxplot
  function drawBox() {
    const a = DS.analysis, nc = a.numeric_columns;
    if (!nc.length) return empty("box", "#chBox", "#capBox", "Brak kolumn liczbowych.");
    if (!window.ChartBoxPlot) return empty("box", "#chBox", "#capBox", "Nie załadowano wtyczki wykresu pudełkowego.");
    const std = $("#boxStd").checked;
    const data = nc.map((c) => {
      const s = a.numeric[c], v = vals(c);
      return std && s.odch_std ? v.map((x) => (x - s.srednia) / s.odch_std) : v;
    });
    mk("box", "#chBox", {
      type: "boxplot",
      data: { labels: nc.map((c) => short(c, 14)), datasets: [{
        label: std ? "z-score" : "wartości", data,
        backgroundColor: C.s1a, borderColor: C.s1, borderWidth: 1.5, medianColor: C.t1, itemRadius: 0,
        outlierBackgroundColor: C.s1, outlierBorderColor: C.surface, outlierRadius: 3.5, coef: 1.5,
        meanBackgroundColor: C.t1, meanRadius: 3, meanStyle: "rectRot",
      }] },
      options: {
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: {
            title: (it) => nc[it[0].dataIndex],
            label: (it) => {
              const s = a.numeric[nc[it.dataIndex]];
              return [` mediana: ${fmt(s.mediana)}`, ` Q1–Q3: ${fmt(s.q1)} – ${fmt(s.q3)}`, ` min–max: ${fmt(s.min)} – ${fmt(s.max)}`,
                ` średnia: ${fmt(s.srednia)}`, ` odstające (IQR): ${s.outliery_iqr}`];
            },
          } },
        },
        scales: {
          x: { grid: { display: false }, border: { color: C.axis }, ticks: { color: C.t2, maxRotation: 30 } },
          y: { ...scaleOpts(std ? "Wartość standaryzowana (z-score)" : "Wartość"), ticks: { color: C.muted, callback: (v) => fmt(v, 2) } },
        },
      },
    });
    $("#capBox").textContent = std
      ? "Kolumny w jednostkach odchylenia standardowego, aby różne skale dało się porównać. Romb = średnia, punkty = obserwacje odstające (1,5·IQR)."
      : "Wartości w oryginalnych jednostkach. Romb = średnia, punkty = obserwacje odstające (1,5·IQR).";
  }

  // --- scatter + regresja liniowa
  function drawScatter() {
    const a = DS.analysis, cx = $("#scX").value, cy = $("#scY").value;
    if (a.numeric_columns.length < 2) return empty("scatter", "#chScatter", "#capScatter", "Potrzebne są co najmniej 2 kolumny liczbowe.");
    const X = a.values[cx], Y = a.values[cy], pts = [];
    for (let i = 0; i < X.length; i++) if (X[i] !== null && Y[i] !== null) pts.push({ x: X[i], y: Y[i] });
    const n = pts.length;
    let sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0;
    pts.forEach(({ x, y }) => { sx += x; sy += y; sxx += x * x; syy += y * y; sxy += x * y; });
    const vx = n * sxx - sx * sx, vy = n * syy - sy * sy;
    const b = vx ? (n * sxy - sx * sy) / vx : 0, a0 = (sy - b * sx) / (n || 1);
    const r = vx && vy ? (n * sxy - sx * sy) / Math.sqrt(vx * vy) : null;
    const xmin = Math.min(...pts.map((p) => p.x)), xmax = Math.max(...pts.map((p) => p.x));
    const line = [{ x: xmin, y: a0 + b * xmin }, { x: xmax, y: a0 + b * xmax }];
    const many = n > 1500;
    mk("scatter", "#chScatter", {
      type: "scatter",
      data: { datasets: [
        { label: "Obserwacje", data: pts, backgroundColor: many ? "rgba(42,120,214,.35)" : "rgba(42,120,214,.7)", borderColor: C.surface,
          borderWidth: many ? 0 : 1, pointRadius: many ? 2.5 : 4.5, pointHoverRadius: 7, order: 2 },
        { type: "line", label: "Regresja liniowa", data: line, borderColor: C.s2, borderWidth: 2, pointRadius: 0, order: 1 },
      ] },
      options: {
        scales: { x: { ...scaleOpts(cx), type: "linear", ticks: { color: C.muted, callback: (v) => fmt(v, 2) } },
                  y: { ...scaleOpts(cy), ticks: { color: C.muted, callback: (v) => fmt(v, 2) } } },
        plugins: { tooltip: { filter: (it) => it.datasetIndex === 0, callbacks: {
          label: (it) => ` ${short(cx, 20)}: ${fmt(it.raw.x)}  ·  ${short(cy, 20)}: ${fmt(it.raw.y)}`,
        } } },
      },
    });
    const sign = b >= 0 ? "+" : "−";
    $("#capScatter").textContent = `r = ${fmt(r, 3)} · R² = ${fmt(r === null ? null : r * r, 3)} · y = ${fmt(a0, 3)} ${sign} ${fmt(Math.abs(b), 4)}·x · n = ${n}`;
  }

  // --- macierz korelacji
  const lerp = (c1, c2, t) => c1.map((v, i) => Math.round(v + (c2[i] - v) * t));
  const corrColor = (r) => {
    if (r === null) return "#ffffff";
    const c = r >= 0 ? lerp(C.divMid, C.divPos, Math.min(1, r)) : lerp(C.divMid, C.divNeg, Math.min(1, -r));
    return `rgb(${c.join(",")})`;
  };
  const cellLabels = {
    id: "cellLabels",
    afterDatasetsDraw(chart) {
      const { ctx } = chart, meta = chart.getDatasetMeta(0), ds = chart.data.datasets[0];
      const n = Math.sqrt(ds.data.length);
      ctx.save(); ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.font = `${n > 8 ? 10 : 12}px system-ui, sans-serif`;
      meta.data.forEach((el, i) => {
        const v = ds.data[i].v; if (v === null) return;
        const { x, y } = el.getCenterPoint();
        ctx.fillStyle = Math.abs(v) > 0.55 ? "#ffffff" : C.t1;
        if (n <= 12) ctx.fillText(fmt(v, 2), x, y);
      });
      ctx.restore();
    },
  };
  function drawCorr() {
    const a = DS.analysis, nc = a.numeric_columns;
    if (nc.length < 2) return empty("corr", "#chCorr", "#capCorr", "Potrzebne są co najmniej 2 kolumny liczbowe.");
    const method = $("#corrMethod").value, M = method === "spearman" ? a.corr_spearman : a.corr_pearson;
    const labels = nc.map((c) => short(c, 14));
    const cells = [];
    nc.forEach((cy, i) => nc.forEach((cx, j) => cells.push({ x: labels[j], y: labels[i], v: M[i][j], cx, cy })));
    const k = nc.length;
    mk("corr", "#chCorr", {
      type: "matrix",
      data: { datasets: [{
        label: "r", data: cells,
        backgroundColor: (ctx) => corrColor(ctx.raw?.v ?? null),
        borderColor: C.surface, borderWidth: 1,
        width: ({ chart }) => ((chart.chartArea || {}).width || 0) / k - 2,
        height: ({ chart }) => ((chart.chartArea || {}).height || 0) / k - 2,
      }] },
      options: {
        plugins: { legend: { display: false }, tooltip: { callbacks: {
          title: () => "", label: (it) => [` ${it.raw.cy}`, ` × ${it.raw.cx}`, ` r = ${fmt(it.raw.v, 4)}`],
        } } },
        scales: {
          x: { type: "category", labels, offset: true, grid: { display: false }, border: { display: false }, ticks: { color: C.t2, maxRotation: 35, autoSkip: false } },
          y: { type: "category", labels, offset: true, reverse: false, grid: { display: false }, border: { display: false }, ticks: { color: C.t2, autoSkip: false } },
        },
      },
      plugins: [cellLabels],
    });
    $("#capCorr").textContent = `Współczynnik ${method === "spearman" ? "Spearmana (rangowy)" : "Pearsona (liniowy)"} · niebieski = dodatnia, czerwony = ujemna, szary ≈ brak związku`;
  }

  // ---------- eksport ----------
  function payload() {
    const images = {};
    for (const [k, ch] of Object.entries(charts)) images[k] = ch.toBase64Image("image/png", 1);
    return {
      id: DS.id, images,
      meta: { title: $("#dashTitle").value.trim() || "Dashboard statystyczny",
        captions: { hist: $("#capHist").textContent, box: $("#capBox").textContent, scatter: $("#capScatter").textContent, corr: $("#capCorr").textContent } },
    };
  }
  $$("[data-export]").forEach((b) => b.addEventListener("click", async () => {
    const fmtName = b.dataset.export; b.disabled = true; loader(true);
    try {
      const r = await api("/api/export", { ...payload(), format: fmtName }, { raw: true });
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.error || "Błąd eksportu"); }
      const blob = await r.blob();
      const cd = r.headers.get("Content-Disposition") || "";
      const m = /filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i.exec(cd);
      const name = m ? decodeURIComponent(m[1] || m[2]) : `dashboard.${fmtName}`;
      const url = URL.createObjectURL(blob), aEl = document.createElement("a");
      aEl.href = url; aEl.download = name; document.body.appendChild(aEl); aEl.click(); aEl.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } catch (e) { status($("#sendStatus"), "err", e.message); }
    finally { b.disabled = false; loader(false); }
  }));

  $("#mailSubj").addEventListener("input", (e) => (e.target.dataset.touched = "1"));
  $("#dashTitle").addEventListener("input", () => { if (!$("#mailSubj").dataset.touched) $("#mailSubj").value = $("#dashTitle").value; });

  $("#sendForm").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const formats = $$("input[name=fmt]:checked").map((i) => i.value);
    if (!formats.length) return status($("#sendStatus"), "err", "Zaznacz co najmniej jeden załącznik.");
    const btn = $("#btnSend"); btn.disabled = true; btn.textContent = "Wysyłanie…";
    status($("#sendStatus"), "info", "Generuję załączniki i łączę się z serwerem poczty…");
    try {
      const j = await api("/api/send", { ...payload(), to: $("#mailTo").value, subject: $("#mailSubj").value, message: $("#mailMsg").value, formats });
      status($("#sendStatus"), j.ok ? "ok" : "err", j.ok ? "✓ " + j.message : j.error);
      if (!j.ok && /nadawcy|SMTP|login|hasło/i.test(j.error)) openSmtp();
    } catch (e) { status($("#sendStatus"), "err", e.message); }
    finally { btn.disabled = false; btn.textContent = "Wyślij mailem"; }
  });

  // ---------- SMTP ----------
  let PRESETS = {};
  async function refreshSmtpState() {
    try {
      const j = await api("/api/smtp"); PRESETS = j.presets; const c = j.config;
      $("#smtpState").innerHTML = c.username && c.has_password
        ? `Poczta: <b>${esc(c.from_email || c.username)}</b> przez ${esc(c.host)}:${c.port}`
        : "Poczta nie jest jeszcze skonfigurowana.";
      return c;
    } catch { return null; }
  }
  async function openSmtp() {
    const c = await refreshSmtpState(); if (!c) return;
    $("#smHost").value = c.host; $("#smPort").value = c.port; $("#smSec").value = c.security;
    $("#smUser").value = c.username; $("#smPass").value = ""; $("#smPass").placeholder = c.has_password ? "•••••• (zapisane – zostaw puste)" : "";
    $("#smFrom").value = c.from_email; $("#smName").value = c.from_name; $("#smRemember").checked = !!c.remember_password;
    $("#smPreset").value = Object.entries(PRESETS).find(([, p]) => p.host === c.host)?.[0] || "";
    status($("#smtpStatus"), "", "");
    $("#smtpModal").classList.remove("hidden");
  }
  const closeSmtp = () => $("#smtpModal").classList.add("hidden");
  $("#btnSmtp").addEventListener("click", openSmtp);
  $("#smCancel").addEventListener("click", closeSmtp);
  $("#smtpModal").addEventListener("click", (e) => { if (e.target.id === "smtpModal") closeSmtp(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeSmtp(); });
  $("#smPreset").addEventListener("change", (e) => {
    const p = PRESETS[e.target.value]; if (!p) return;
    $("#smHost").value = p.host; $("#smPort").value = p.port; $("#smSec").value = p.security;
  });
  $("#smUser").addEventListener("change", () => { if (!$("#smFrom").value && $("#smUser").value.includes("@")) $("#smFrom").value = $("#smUser").value; });
  async function saveSmtp() {
    const j = await api("/api/smtp", {
      host: $("#smHost").value.trim(), port: $("#smPort").value, security: $("#smSec").value,
      username: $("#smUser").value.trim(), password: $("#smPass").value, from_email: ($("#smFrom").value || $("#smUser").value).trim(),
      from_name: $("#smName").value.trim(), remember_password: $("#smRemember").checked,
    });
    if (!j.ok) throw new Error(j.error);
    refreshSmtpState(); return j;
  }
  $("#smSave").addEventListener("click", async () => {
    try { await saveSmtp(); status($("#smtpStatus"), "ok", "Zapisano ustawienia."); setTimeout(closeSmtp, 700); }
    catch (e) { status($("#smtpStatus"), "err", e.message); }
  });
  $("#smTest").addEventListener("click", async () => {
    const b = $("#smTest"); b.disabled = true; status($("#smtpStatus"), "info", "Łączę się z serwerem…");
    try { await saveSmtp(); const j = await api("/api/smtp/test", {}); status($("#smtpStatus"), j.ok ? "ok" : "err", j.ok ? "✓ " + j.message : j.error); }
    catch (e) { status($("#smtpStatus"), "err", e.message); }
    finally { b.disabled = false; }
  });

  refreshSmtpState();
})();
